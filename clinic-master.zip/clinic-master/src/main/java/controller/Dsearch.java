package controller;

import java.sql.Connection;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ConnectionDao;
import model.DoctorSearch;


@WebServlet("/searchDoctor")
public class Dsearch extends HttpServlet {
        private static final long serialVersionUID = 1L;

        public Dsearch() {
            super();
        }


        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            Connection conn = ConnectionDao.getConnection();
            String sql="select NameAndSurname, PhoneNumber from tblusers where TypeOfUsers='medic'";
            try {
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql);
                DoctorSearch DS = new DoctorSearch();
                while(rs.next()) {
                    DS.setNameAndSurname(rs.getString("NameAndSurname"));
                    DS.setPhoneNumber(rs.getString("PhoneNumber"));
                }

                request.setAttribute("DoctorSearch", DS);

                request.getRequestDispatcher("/searchDoctor.jsp").forward(request, response);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request, response);
        }

}
