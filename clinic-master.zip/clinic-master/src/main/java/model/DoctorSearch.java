package model;


public class DoctorSearch {

        private String NameAndSurname;
        private String PhoneNumber;

        public String getNameAndSurname() {
            return NameAndSurname;
        }

        public void setNameAndSurname(String NameAndSurname) {
            this.NameAndSurname = NameAndSurname;
        }

        public String getPhoneNumber() {
            return PhoneNumber;
        }

        public void setPhoneNumber(String PhoneNumber) {
            this.PhoneNumber = PhoneNumber;
        }


        @Override
        public String toString() {
            return "DS [DoctorName=" + NameAndSurname + ", Phone_no=" + PhoneNumber +"]" ;
        }

        public DoctorSearch(String NameAndSurname, String PhoneNumber) {
            super();
            this.NameAndSurname = NameAndSurname;
            this.PhoneNumber = PhoneNumber;
        }

        public DoctorSearch() {
            super();
        }


}
